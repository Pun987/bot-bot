import React, { useState } from "react";

export default function App() {
  const [history, setHistory] = useState(() => {
    const saved = localStorage.getItem("baccarat-history");
    return saved ? JSON.parse(saved) : [];
  });

  const [suggestion, setSuggestion] = useState("");
  const [confidence, setConfidence] = useState(0);

  const addResult = (result) => {
    const newHistory = [...history, result];
    setHistory(newHistory);
    localStorage.setItem("baccarat-history", JSON.stringify(newHistory));
    analyze(newHistory);
    playSound();
  };

  const analyze = (h) => {
    let rec = "ไม่มีคำแนะนำ";
    let conf = 50;
    const len = h.length;

    if (len >= 3) {
      const [a, b, c] = h.slice(-3);
      if (a === b && b === c) {
        rec = `แทง ${a}`;
        conf = 85;
      } else if (a !== b && b !== c) {
        rec = `แทง ${a}`;
        conf = 70;
      } else if (len >= 4 && h[len - 1] === h[len - 2] && h[len - 3] !== h[len - 4]) {
        rec = `แทง ${h[len - 1]}`;
        conf = 65;
      }
    }
    setSuggestion(rec);
    setConfidence(conf);
  };

  const playSound = () => {
    const audio = new Audio("https://www.soundjay.com/buttons/sounds/button-29.mp3");
    audio.play();
  };

  return (
    <div style={{ padding: '1rem', fontFamily: 'sans-serif', maxWidth: '500px', margin: '0 auto' }}>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', textAlign: 'center' }}>สรูตบาเฮียปั้น</h1>
      <div style={{ display: 'flex', justifyContent: 'center', gap: '0.5rem', marginTop: '1rem' }}>
        <button onClick={() => addResult("Player")}>Player</button>
        <button onClick={() => addResult("Banker")}>Banker</button>
        <button onClick={() => addResult("Tie")}>Tie</button>
      </div>
      <div style={{ marginTop: '1rem' }}>
        <h2>ประวัติผลล่าสุด:</h2>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
          {history.map((item, idx) => (
            <span key={idx} style={{ padding: '0.3rem 0.6rem', background: '#eee', borderRadius: '5px' }}>{item}</span>
          ))}
        </div>
      </div>
      <div style={{ marginTop: '1rem' }}>
        <h2>คำแนะนำ:</h2>
        <p style={{ fontSize: '1.2rem' }}>{suggestion}</p>
        <p style={{ color: '#666' }}>ความมั่นใจ: {confidence}%</p>
      </div>
    </div>
  );
}